Option Explicit

Dim shell, files, root, pythonwCommand, command, setupScript, marker, rc
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
root = files.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
marker = root & "\.packages\.fischmate_ready"
setupScript = root & "\Setup FischMate.vbs"

' First launch: install FischMate's Python packages into an isolated folder.
If Not files.FileExists(marker) Then
    rc = MsgBox( _
        "FischMate needs a quick one-time setup before it can open on this PC." & vbCrLf & vbCrLf & _
        "This installs the required Python packages inside the FischMate folder. " & _
        "FischMate itself remains script-based and does not include an .exe or .bat file." & vbCrLf & vbCrLf & _
        "Run setup now?", _
        36, "FischMate - First-time setup")

    If rc <> 6 Then
        WScript.Quit 0
    End If

    If Not files.FileExists(setupScript) Then
        MsgBox "Setup FischMate.vbs is missing from this FischMate folder.", 16, "FischMate"
        WScript.Quit 1
    End If

    command = Chr(34) & shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe" & Chr(34) & _
              " " & Chr(34) & setupScript & Chr(34)
    shell.Run command, 1, True

    If Not files.FileExists(marker) Then
        WScript.Quit 1
    End If
End If

' Prefer the standard Python launcher because it resolves the user's real
' Python install instead of relying on a Store alias or a hard-coded path.
On Error Resume Next
Err.Clear
command = "pyw.exe -3 " & Chr(34) & root & "\FischMate.pyw" & Chr(34)
shell.Run command, 0, False
If Err.Number = 0 Then
    WScript.Quit 0
End If

Err.Clear
command = "pythonw.exe " & Chr(34) & root & "\FischMate.pyw" & Chr(34)
shell.Run command, 0, False
If Err.Number = 0 Then
    WScript.Quit 0
End If
On Error GoTo 0

MsgBox "FischMate could not find Python 3 on this PC." & vbCrLf & vbCrLf & _
       "Install Python 3 from python.org, then open FischMate again.", _
       48, "FischMate - Python needed"
