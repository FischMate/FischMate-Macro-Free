Option Explicit

Dim shell, files, root, packagesDir, marker, requirementsFile
Dim pythonPrefix, testCommand, installCommand, rc, markerFile

Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
root = files.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
packagesDir = root & "\.packages"
marker = packagesDir & "\.fischmate_ready"
requirementsFile = root & "\requirements.txt"

If Not files.FileExists(requirementsFile) Then
    MsgBox "requirements.txt is missing from the FischMate folder.", 16, "FischMate Setup"
    WScript.Quit 1
End If

pythonPrefix = FindPython(shell)
If pythonPrefix = "" Then
    MsgBox "Python 3 was not found on this PC." & vbCrLf & vbCrLf & _
           "Install Python 3 for Windows from python.org, then run FischMate again.", _
           48, "FischMate Setup"
    WScript.Quit 1
End If

rc = MsgBox( _
    "FischMate will now install its required Python packages into:" & vbCrLf & vbCrLf & _
    packagesDir & vbCrLf & vbCrLf & _
    "This keeps FischMate isolated from your other Python projects." & vbCrLf & _
    "The setup may take a minute on the first run.", _
    64, "FischMate Setup")

On Error Resume Next
If files.FolderExists(packagesDir) Then
    files.DeleteFolder packagesDir, True
End If
On Error GoTo 0

files.CreateFolder packagesDir

installCommand = pythonPrefix & _
    " -m pip install --disable-pip-version-check --no-warn-script-location --upgrade" & _
    " --target " & Q(packagesDir) & _
    " -r " & Q(requirementsFile)

' Use the installed Python console for setup so failures are visible instead
' of disappearing behind pythonw. Nothing executable is bundled with FischMate.
rc = shell.Run(installCommand, 1, True)
If rc <> 0 Then
    On Error Resume Next
    If files.FileExists(marker) Then files.DeleteFile marker, True
    On Error GoTo 0
    MsgBox "FischMate setup did not complete." & vbCrLf & vbCrLf & _
           "Please check the Python/pip error shown in the setup window, then run setup again.", _
           16, "FischMate Setup"
    WScript.Quit rc
End If

' Verify the exact imports FischMate needs before marking setup as complete.
testCommand = pythonPrefix & " -c " & Q( _
    "import sys; sys.path.insert(0, sys.argv[1]); import numpy, cv2, dxcam, mss, yaml") & _
    " " & Q(packagesDir)
rc = shell.Run(testCommand, 0, True)
If rc <> 0 Then
    MsgBox "The packages installed, but FischMate's dependency check failed." & vbCrLf & vbCrLf & _
           "Run Setup FischMate.vbs again. If it still fails, make sure you are using a current 64-bit Python 3 release.", _
           16, "FischMate Setup"
    WScript.Quit rc
End If

Set markerFile = files.CreateTextFile(marker, True)
markerFile.WriteLine "FischMate dependency setup completed."
markerFile.Close

MsgBox "Setup complete." & vbCrLf & vbCrLf & _
       "You can now open FischMate.vbs or use the FischMate shortcut.", _
       64, "FischMate Setup"
WScript.Quit 0

Function FindPython(sh)
    Dim result, code
    result = ""

    On Error Resume Next
    Err.Clear
    code = sh.Run("py.exe -3 -c " & Q("import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"), 0, True)
    If Err.Number = 0 And code = 0 Then
        result = "py.exe -3"
        On Error GoTo 0
        FindPython = result
        Exit Function
    End If

    Err.Clear
    code = sh.Run("python.exe -c " & Q("import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"), 0, True)
    If Err.Number = 0 And code = 0 Then
        result = "python.exe"
    End If
    On Error GoTo 0

    FindPython = result
End Function

Function Q(value)
    Q = Chr(34) & value & Chr(34)
End Function
