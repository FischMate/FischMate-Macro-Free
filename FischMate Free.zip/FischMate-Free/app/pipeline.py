from __future__ import annotations

from app.controller.standard import StandardController
from app.detection.standard import StandardDetector
from app.executor.safe import InputDisabledExecutor
from app.lifecycle.coordinator import FishingCoordinator, LifecycleExecutor
from app.lifecycle.machine import LifecycleMachine
from app.core.models import FramePacket, LifecycleState, PipelineResult


class MacroPipeline:
    """Fishing pipeline for standard-mechanics rods in FischMate Free."""

    def __init__(
        self,
        profile: dict,
        executor: LifecycleExecutor | None = None,
        automate_lifecycle: bool = False,
    ):
        self.profile = profile
        self.detector = StandardDetector(profile)
        self.controller = StandardController(profile)
        self.executor = executor or InputDisabledExecutor()
        self.lifecycle = LifecycleMachine(profile)
        self.automate_lifecycle = automate_lifecycle
        self.coordinator = FishingCoordinator(profile, self.lifecycle, self.executor)

    def reset(self, now_ms: float = 0.0) -> None:
        self.detector.reset()
        self.controller.reset()
        self.coordinator.reset(now_ms)

    def start_automation(self, now_ms: float) -> None:
        if not self.automate_lifecycle:
            raise RuntimeError("This pipeline was not created for live automation")
        self.coordinator.start(now_ms)

    def stop_automation(self, now_ms: float, reason: str = "emergency_stop") -> None:
        self.coordinator.stop(now_ms, reason)

    def process(self, packet: FramePacket) -> PipelineResult:
        observation = self.detector.detect(packet)
        previous_state = self.lifecycle.state
        state = (
            self.coordinator.update(observation)
            if self.automate_lifecycle
            else self.lifecycle.update(observation)
        )
        if previous_state == LifecycleState.RECOVERY and state == LifecycleState.PREPARING:
            self.detector.reset()
            self.controller.reset()
        command = self.controller.decide(observation)
        perfect_now, margin = self.controller.perfect_measurement(observation)
        if not self.automate_lifecycle or state == LifecycleState.MINIGAME:
            self.executor.submit(command)
        return PipelineResult(packet, observation, state, command, perfect_now, margin)
