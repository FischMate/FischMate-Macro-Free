"""FischMate product branding."""

APP_NAME = "FischMate Macro"
APP_TAGLINE = "Easy fishing helper for Roblox"
PROJECT_DESCRIPTION = "Screen-based fishing automation for Fisch"
