from __future__ import annotations

import tkinter as tk
from pathlib import Path

from app.branding import APP_NAME
from app.gui.fonts import load_bundled_fonts
from app.gui.main_window import MacroWindow


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    load_bundled_fonts(PROJECT_ROOT)
    root = tk.Tk()
    MacroWindow(root, PROJECT_ROOT)
    root.mainloop()


if __name__ == "__main__":
    main()
