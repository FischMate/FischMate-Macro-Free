from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from collections.abc import Callable

from app.capture.sources import DxcamWindowSource, FrameSource
from app.capture.windows import WindowInfo, is_foreground_window
from app.executor.windows import InterruptibleInputExecutor, WindowsSendInputBackend
from app.pipeline import MacroPipeline


@dataclass(frozen=True)
class LiveStatus:
    running: bool
    lifecycle: str
    message: str = ""


class LiveDetectionEngine:
    """Runs FischMate's live fishing pipeline without recording session data."""

    def __init__(
        self,
        project_root: Path,
        status_callback: Callable[[LiveStatus], None],
        source_factory: Callable[[WindowInfo], FrameSource] = DxcamWindowSource,
    ):
        self.project_root = project_root
        self.status_callback = status_callback
        self.source_factory = source_factory
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._executor: InterruptibleInputExecutor | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self, window: WindowInfo, profile: dict) -> None:
        if self.running:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run,
            args=(window, profile),
            name="fischmate-live",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self.emergency_release()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=2.0)

    def emergency_release(self) -> None:
        self._stop.set()
        executor = self._executor
        if executor is not None:
            executor.set_enabled(False)

    def _run(self, window: WindowInfo, profile: dict) -> None:
        source: FrameSource | None = None
        try:
            if not is_foreground_window(window):
                raise RuntimeError(
                    "Select Roblox and keep it in the foreground before starting FischMate"
                )
            source = self.source_factory(window)
            enabled_mechanics = profile.get("mechanics", {}).get("enabled", [])
            maximum_mouse_down_bpm = (
                float(
                    profile["input"].get(
                        "maximum_mouse_transition_bpm",
                        profile["input"].get("maximum_mouse_down_bpm"),
                    )
                )
                if "rate_limited_clicking" in enabled_mechanics
                else None
            )
            input_config = profile.get("input", {})
            executor = InterruptibleInputExecutor(
                WindowsSendInputBackend(),
                enabled=True,
                maximum_mouse_down_bpm=maximum_mouse_down_bpm,
                mouse_down_timing=str(
                    input_config.get("mouse_down_timing", "minimum_interval")
                ),
                mouse_down_beat_window_ms=float(
                    input_config.get("mouse_down_beat_window_ms", 70)
                ),
            )
            self._executor = executor
            pipeline = MacroPipeline(profile, executor=executor, automate_lifecycle=True)
            report_started = time.perf_counter()
            automation_started = False
            last_lifecycle = "PREPARING"
            while not self._stop.is_set():
                if not is_foreground_window(window):
                    raise RuntimeError("FischMate stopped because Roblox lost foreground focus")
                packet = source.read()
                if packet is None:
                    time.sleep(0.002)
                    continue
                if not automation_started:
                    pipeline.start_automation(packet.timestamp_ms)
                    automation_started = True
                result = pipeline.process(packet)
                last_lifecycle = result.lifecycle.value
                now = time.perf_counter()
                if now - report_started >= 0.1:
                    self.status_callback(LiveStatus(True, last_lifecycle))
                    report_started = now
            self.status_callback(LiveStatus(False, "STOPPED"))
        except Exception as exc:
            self.emergency_release()
            self.status_callback(LiveStatus(False, "ERROR", str(exc)))
        finally:
            self.emergency_release()
            if source is not None:
                source.close()
            self._executor = None
