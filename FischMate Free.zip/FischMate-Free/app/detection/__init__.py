from .standard import StandardDetector

__all__ = ["StandardDetector"]
