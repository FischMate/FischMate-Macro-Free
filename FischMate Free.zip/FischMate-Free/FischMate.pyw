from __future__ import annotations

import ctypes
import sys
import traceback
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACKAGES_DIR = ROOT / ".packages"
if PACKAGES_DIR.is_dir():
    # Keep FischMate dependencies isolated from the user's global Python packages.
    sys.path.insert(0, str(PACKAGES_DIR))

_MUTEX_HANDLE = None


def _message(title: str, body: str, icon: int = 0x30) -> None:
    if sys.platform == "win32":
        try:
            ctypes.windll.user32.MessageBoxW(None, body, title, icon)
            return
        except Exception:
            pass
    print(f"{title}: {body}", file=sys.stderr)


def _claim_single_instance() -> bool:
    """Prevent accidental repeated shortcut clicks from stacking hidden copies."""
    global _MUTEX_HANDLE
    if sys.platform != "win32":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        handle = kernel32.CreateMutexW(None, False, "Local\\FischMateMacro.SingleInstance")
        if not handle:
            return True
        _MUTEX_HANDLE = handle
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            _message(
                "FischMate is already open",
                "Another FischMate window is already running. Check the taskbar or Task Manager before starting another copy.",
                0x40,
            )
            return False
    except Exception:
        return True
    return True


def _run() -> None:
    if not _claim_single_instance():
        return
    try:
        from app.main import main
        main()
    except Exception:
        details = traceback.format_exc()
        log_path = ROOT / "FischMate-startup-error.txt"
        try:
            log_path.write_text(details, encoding="utf-8")
        except OSError:
            pass
        _message(
            "FischMate could not start",
            "FischMate hit a startup error. No background automation was started.\n\n"
            "If this is the first launch, run 'Setup FischMate.vbs' once.\n\n"
            "Technical details were saved to:\n"
            f"{log_path}",
            0x10,
        )


if __name__ == "__main__":
    _run()
