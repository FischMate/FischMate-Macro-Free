Option Explicit

Dim shell, files, root, shortcut, wscriptExe
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
root = files.GetParentFolderName(WScript.ScriptFullName)
wscriptExe = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe"

Set shortcut = shell.CreateShortcut(root & "\FischMate.lnk")
shortcut.TargetPath = wscriptExe
shortcut.Arguments = Chr(34) & root & "\FischMate.vbs" & Chr(34)
shortcut.WorkingDirectory = root
shortcut.Description = "Launch FischMate Macro"
shortcut.IconLocation = root & "\assets\fischmate.ico,0"
shortcut.WindowStyle = 1
shortcut.Save

MsgBox "FischMate.lnk is ready. You can move or copy it to your Desktop.", 64, "FischMate"
